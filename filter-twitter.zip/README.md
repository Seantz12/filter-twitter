# filter-twitter
An automatic filtering of posts that you're not interested in

So far all it does is filter posts without images or videos, because I'm not browsing twitter for text, I'm browsing it for art.

May look into doing things like

* Only images! Aka by deleting even the text captions
* Maybe hide tweets with image, then click to show? might be better flow wise?

Problems/Known issues:

* If the hidden tweet is a reply tweet, makes the next tweet look like a reply
* Have to enable it to always read data from site, default load is only when clicked (which does not work) 